const express = require('express')
const { MongoClient } = require('mongodb')
const port = 5000

const app = express()

app.use(express.json())

const client = new MongoClient('mongodb://127.0.0.1:27017')

const db = client.db('yemak')
const users = db.collection('users')
const restaurants = db.collection('restaurants')

app.get('/restaurants', async (req, res) => {
    const restaurantsList = await restaurants.find().toArray()
    res.status(200).json({
        status: true,
        restaurants: restaurantsList
    })
})

app.post('/restaurants/add', async (req, res) => {
    const { name,phone_number, s_work_time, e_work_time, work_status, address } = req.body

    await restaurants.insertOne({
        name,phone_number, s_work_time, e_work_time, work_status, address
    })

    res.status(201).json({
        status: true,
        message: 'Restaurant added successfuly'
    })
})

app.listen(port, () => console.log('Server running on port', port))